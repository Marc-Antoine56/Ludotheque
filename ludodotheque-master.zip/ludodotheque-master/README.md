# ludodotheque

// CONVENTION DE NOMMAGE :

private _uneVariable;

public uneVariable;

// NOMMAGE TOUT EN FRANCAIS 

// METTRE SON NOM AU DESSUS DES CLASSES QU'ON CREE

// A CHAQUE PUSH ECRIRE : prenom - heure - minute - message commit
