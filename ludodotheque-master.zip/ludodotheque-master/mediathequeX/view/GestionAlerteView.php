<!DOCTYPE html>
<html>
    <head>
        <title>Mediathèque : Alerte</title>
 		
 		<?php require("view/require/HeadReferenceView.php");?>
    </head>

    <body>
		<?php require("view/require/HeaderView.php");
		
              require("view/require/SearchBarView.php");
        		
        	  require("view/require/FooterView.php");?>
				
    </body>
</html>