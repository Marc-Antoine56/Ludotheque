<footer class="footer">
	<div class="container centrer">
	    <div class="row"  >
    	    <div class="col-md-10" >
            	2019 Copyright : 
            	<a href="http://greta-bretagne.ac-rennes.fr/portail/web/greta-est-bretagne/st-malo/stages/bts-services-informatiques-aux"> 
            	BTS SIO Vannes
            	</a>
    		</div>
    		
            <div class="col-md-2" >
        		<a href="mailto:media@theque.com" class="btn btn-primary btn-default"><span class="glyphicon glyphicon-envelope"></span> Contact</a>
    		</div>
		</div>
</footer>