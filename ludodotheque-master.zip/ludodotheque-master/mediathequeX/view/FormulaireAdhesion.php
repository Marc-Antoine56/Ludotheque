<!DOCTYPE html>
<html>
    <head>
        <title>Mediathèque : Formulaire Adhérent</title>
 	
 		<?php require("view/require/HeadReferenceView.php");?>
    </head>

    <body>
		<?php require("view/require/HeaderView.php");
		
		      require("view/require/FormulaireView.php");
		
		      require("view/require/FooterView.php");?>
		
    </body>
</html>
