<?php 
function GestionAlertePage()
{
    require("view/GestionAlerteView.php");
}